# Copyright 1999-2025 Gentoo Authors
# Distributed under the terms of the GNU General Public License v2

EAPI=8

DISTUTILS_EXT=1
DISTUTILS_USE_PEP517=no
PYTHON_COMPAT=( python3_{11..12} python3_{13..14}{,t} pypy3_11 )
PYTHON_REQ_USE="threads(+)"

inherit meson distutils-r1

DESCRIPTION="Python bindings for the cairo library"
HOMEPAGE="
	https://www.cairographics.org/pycairo/
	https://github.com/pygobject/pycairo/
	https://pypi.org/project/pycairo/
"
SRC_URI="
	https://github.com/pygobject/${PN}/releases/download/v${PV}/${P}.tar.gz
"

LICENSE="|| ( LGPL-2.1 MPL-1.1 )"
SLOT="0"
KEYWORDS="~alpha amd64 arm arm64 ~hppa ~loong ~mips ppc ppc64 ~riscv ~s390 ~sparc x86 ~x64-macos"
IUSE="X examples test"
RESTRICT="!test? ( test )"

RDEPEND="
	>=x11-libs/cairo-1.15.10[svg(+),X=]
"
DEPEND="
	${RDEPEND}
	X? ( x11-base/xorg-protoa )
"
BDEPEND="
	virtual/pkgconfig
	test? (
		dev-python/hypothesis[${PYTHON_USEDEP}]
	)
"

distutils_enable_sphinx docs \
	dev-python/sphinx-rtd-theme
distutils_enable_tests pytest

python_compile() {
	local emesonargs=(
		# TODO: move that to the eclass?
		-Dpython.bytecompile=2
		-Dtests="$(usex test true false)"
	)

	meson_src_configure
	meson_src_compile
}

python_test() {
	cd "${BUILD_DIR}" || die

	local -x PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
	epytest
}

python_install() {
	meson_src_install
}

python_install_all() {
	if use examples; then
		dodoc -r examples
	fi

	distutils-r1_python_install_all
}
